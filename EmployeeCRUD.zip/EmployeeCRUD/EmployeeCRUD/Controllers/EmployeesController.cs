﻿using EmployeeCRUD.Data;
using EmployeeCRUD.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;


namespace EmployeeCRUD.Controllers
{
    public class EmployeesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public EmployeesController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(string searchString, string sortOrder, string currentFilter, int? pageNumber)
        {
            ViewData["CurrentSort"] = sortOrder;
            ViewData["UsernameSortParm"] = String.IsNullOrEmpty(sortOrder) ? "username_desc" : "";
            ViewData["GenderSortParm"] = sortOrder == "Gender" ? "gender_desc" : "Gender";
            ViewData["DepartmentSortParm"] = sortOrder == "Department" ? "department_desc" : "Department";

            if (searchString != null)
            {
                pageNumber = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewData["CurrentFilter"] = searchString;

            var employees = from e in _context.Employees
                            select e;
            if (!String.IsNullOrEmpty(searchString))
            {
                searchString = searchString.ToLower();
                var searchParts = searchString.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);


                employees = employees.Where(e =>
             searchParts.Any(s => e.Username.ToLower().Contains(s)) ||
             searchParts.Any(s => e.Gender.ToLower().Equals(s)) ||
             searchParts.Any(s => e.Department.ToLower().Contains(s)) ||
             searchParts.All(s => e.Skills.ToLower().Contains(s)));

            }

            switch (sortOrder)
            {
                case "username_desc":
                    employees = employees.OrderByDescending(e => e.Username);
                    break;
                case "Gender":
                    employees = employees.OrderBy(e => e.Gender);
                    break;
                case "gender_desc":
                    employees = employees.OrderByDescending(e => e.Gender);
                    break;
                case "Department":
                    employees = employees.OrderBy(e => e.Department);
                    break;
                case "department_desc":
                    employees = employees.OrderByDescending(e => e.Department);
                    break;
                default:
                    employees = employees.OrderBy(e => e.Username);
                    break;
            }

            return View(await employees.AsNoTracking().ToListAsync());
        }


        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("FirstName,LastName,DateOfJoining,Department,Skills,Salary,Username,Password,Gender,Age")] Employee employee, string[] Skills)
        {
            employee.Skills = Skills != null ? string.Join(",", Skills) : string.Empty;
            if (ModelState.IsValid)
            {

                _context.Add(employee);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(employee);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employees.FindAsync(id);
            if (employee == null)
            {
                return NotFound();
            }
            return View(employee);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,FirstName,LastName,DateOfJoining,Department,Skills,Salary,Username,Password,Gender,Age")] Employee employee, string[] Skills)
        {

            if (id != employee.Id)
            {
                return NotFound();
            }
            employee.Skills = Skills != null ? string.Join(",", Skills) : string.Empty;
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(employee);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EmployeeExists(employee.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(employee);
        }
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employees
                .FirstOrDefaultAsync(m => m.Id == id);
            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employees
                .FirstOrDefaultAsync(m => m.Id == id);
            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var employee = await _context.Employees.FindAsync(id);
            _context.Employees.Remove(employee);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        public IActionResult AdvancedSearch()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AdvancedSearch(string firstName, int? minAge, int? maxAge, float? minSalary, float? maxSalary, string gender, string skills)
        {
            var employees = from e in _context.Employees
                            select e;

            if (!string.IsNullOrEmpty(firstName))
            {
                employees = employees.Where(e => e.FirstName.ToLower().Contains(firstName.ToLower()));
            }

            if (minAge.HasValue)
            {
                employees = employees.Where(e => e.Age >= minAge.Value);
            }

            if (maxAge.HasValue)
            {
                employees = employees.Where(e => e.Age <= maxAge.Value);
            }

            if (minSalary.HasValue)
            {
                employees = employees.Where(e => e.Salary == minSalary.Value);
            }

            if (maxSalary.HasValue)
            {
                employees = employees.Where(e => e.Salary == maxSalary.Value);
            }

            if (!string.IsNullOrEmpty(gender))
            {
                employees = employees.Where(e => e.Gender.ToLower() == gender.ToLower());
            }

            if (!string.IsNullOrEmpty(skills))
            {
                var skillList = skills.ToLower().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                employees = employees.Where(e => skillList.All(skill => e.Skills.ToLower().Contains(skill)));
            }




            var employeeList = await employees.AsNoTracking().ToListAsync();

            ViewData["AverageSalary"] = employees.Any() ? employees.Average(e => e.Salary) : 0;
            ViewData["MaxSalary"] = employees.Any() ? employees.Max(e => e.Salary) : 0;
            ViewData["MinSalary"] = employees.Any() ? employees.Min(e => e.Salary) : 0;

            return View("AdvancedSearchResults", employeeList);
        }
        private bool EmployeeExists(int id)
        {
            return _context.Employees.Any(e => e.Id == id);
        }
    }
}
        
    


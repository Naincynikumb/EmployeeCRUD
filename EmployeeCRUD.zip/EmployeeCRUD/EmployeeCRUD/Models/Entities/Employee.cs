﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;



namespace EmployeeCRUD.Models
    {
        public class Employee
        {
            public int Id { get; set; }

            [Required(ErrorMessage = "First Name is required")]
            [Display(Name = "First Name")]
            [StringLength(50, ErrorMessage = "First Name cannot exceed 50 characters")]
            public string FirstName { get; set; }

            [Required(ErrorMessage = "Last Name is required")]
            [Display(Name = "Last Name")]
            [StringLength(50, ErrorMessage = "Last Name cannot exceed 50 characters")]
            public string LastName { get; set; }

            [NotMapped]
            [Display(Name = "Full Name")]
            public string FullName => $"{FirstName} {LastName}";

            [Required(ErrorMessage = "Date of Joining is required")]
            [Display(Name = "Date of Joining")]
            [DataType(DataType.Date)]
            public DateTime DateOfJoining { get; set; }

            [Required(ErrorMessage = "Department is required")]
            public string Department { get; set; }

            [Required(ErrorMessage = "At least one skill is required")]
            public string Skills { get; set; }

            [Required(ErrorMessage = "Salary is required")]
            [Range(0, double.MaxValue, ErrorMessage = "Salary must be a positive number")]
            public double Salary { get; set; }

            [Required(ErrorMessage = "Username is required")]
            [EmailAddress(ErrorMessage = "Invalid Email Address")]
            public string Username { get; set; }

            [Required(ErrorMessage = "Password is required")]
            [StringLength(100, MinimumLength = 10, ErrorMessage = "Password must be at least 10 characters long")]
            [RegularExpression(@"^(?=.*[A-Z])(?=.*[!@#$&*]).{10,}$", ErrorMessage = "Password must contain at least one uppercase letter and one special character")]
            public string Password { get; set; }

            [Required(ErrorMessage = "Gender is required")]
            public string Gender { get; set; }

            [Required(ErrorMessage = "Age is required")]
            [Range(0, 150, ErrorMessage = "Age must be a positive integer")]
            public int Age { get; set; }
        }
    }



